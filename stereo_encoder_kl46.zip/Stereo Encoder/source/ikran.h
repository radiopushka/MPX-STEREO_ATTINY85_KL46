/*
 * ikran.h
 *
 *  Created on: Jan 23, 2023
 *      Author: Evan Nikitin
 */


#ifndef IKRAN_H_
#define IKRAN_H_

#define CLEAR_T 0
#define SET_T 1

#define SEGA 0x88
#define SEGB 0x44
#define SEGC 0x22
#define SEGD 0x11
#define SEGE 0x22
#define SEGF 0x44
#define SEGG 0x88

void trigger_trace(short segmentfront,short segmentback,short position,char clear); //turn on a segment on the lcd

//short Get_Pin(char number);//converts integeres into the LCD front pins
//void turn_on_rows();//turns on all the different back pane clock signals
void clear_display();//clear the screen
void setup_display();//setup function
void display_digit(char in,char row);//display a letter or number in one of the 4 ечейки
void display_text(char *in);//duh
void display_number(short num); //display a large number
void scrolling_text_dialogue(char* input); //user friendly scrolling dialogue
char number_select(char *show,short bounds); //user friendly number chooser
char getkey(); //similar function to the ncurses library in linux

#endif /* IKRAN_H_ */
