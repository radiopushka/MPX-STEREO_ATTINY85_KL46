/*
 * Copyright 2016-2023 NXP
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of NXP Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file    Stereo Encoder.c
 * @brief   ApplicL_v++ation entry point.
 */
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL46Z4.h"
#include "fsl_debug_console.h"
/* TODO: insert other include files here. */
#include "ikran.h"
/* TODO: insert other definitions and declarations here. */

/*
 * @brief   Application entry point.
 */
volatile char interrupt=0;
//DAC limiter
volatile int DAC_limit=2700;//maximum 4095
volatile int DAC_vol=1;
//stereo generator
volatile int ST_diff=11;//5-15
volatile int ST_gate=10;
volatile int ST_limit=500;//max 630
//stereo pilot tone
volatile int pilot_att=2;
//audio compressor (R+L):
volatile float ratio=1.0; //1-2
volatile int threshold=9000;//100-2000
volatile int gate=6000;

volatile char menu_pos=0;
//menu: "on", Mono limiter, Stereo difference, Stereo gate, Stereo Limiter, Right volume, Left volume, Stereo pilot attenuation
void set_pilot_att(){
	TPM1->CONTROLS[0].CnV=((48000/19)/2)/pilot_att;//pilot signal duty cycle set

}
void PORTC_PORTD_IRQHandler(){//button interrupt handler, need this because audio processing is intensive
   if((PORTC->PCR[3]&(1<<24))!=0){

	   menu_pos++;

   }
   if(menu_pos>7){menu_pos=0;}//menu position

   if((PORTC->PCR[12]&(1<<24))!=0){

       switch(menu_pos){
       case 1:
    	   DAC_limit=DAC_limit+100;

    	   if(DAC_limit>4095){//maximum limiter value
    		   DAC_limit=2000;
    	   }
    	   if(DAC_limit>=4000){
    	       		   DAC_limit=4095;
    	       	   }
    	   break;
       case 2:
    	   ST_diff++;
    	   if(ST_diff>15){//maximum difference value
    		   ST_diff=1;
    	   }
    	   break;
       case 3:
    	   ST_gate++;
    	   if(ST_gate>90){//stereo noise gate, usually no need to adjust
    		   ST_gate=3;
    	   }
    	   break;
       case 4:
    	   ST_limit=ST_limit+10;
    	   if(ST_limit>630){//stereo difference limiter max value
    		   ST_limit=300;
    	   }
    	   break;
       case 5:
    	   ratio=ratio+0.01;
    	   if(ratio>2){//compression ratio value
    		   ratio=0.1;
    	   }
    	   break;
       case 6:
    	   threshold=threshold+1000;
    	   if(threshold>80000){//compression threshold value
    		   threshold=6000;
    	   }
    	   break;
       case 7:
    	   pilot_att=pilot_att+1;
    	   if(pilot_att>50){//stereo 19khz pilot tone duty cycle or amplitude when converting
    		   pilot_att=1;
    	   }
    	   set_pilot_att();
    	   break;

       }


   }
   switch (menu_pos){
      case 0:
      clear_display();//extension of the user display, see the lcd Икран.h library i wrote at begining of semester
      display_text("on");
      break;
      case 1:
    	  clear_display();
    	  display_digit('M',3);
    	  display_digit('L',2);
    	  display_digit(DAC_limit/1000,1);
    	  display_digit((DAC_limit/100)-(DAC_limit/1000)*10,0);
    	  break;
      case 2:
    	  clear_display();
    	  display_digit('S',3);
    	  display_digit('D',2);
    	  display_digit(ST_diff/10,1);
    	  display_digit(ST_diff-(ST_diff/10)*10,0);
    	  break;
      case 3:
          	  clear_display();
          	  display_digit('S',3);
          	  display_digit('G',2);
              display_digit(ST_gate/10,1);
          	  display_digit(ST_gate-(ST_gate/10)*10,0);
          	  break;
      case 4:

          	  clear_display();
          	  display_digit('S',3);
          	  display_digit('L',2);
          	  display_digit(ST_limit/100,1);
          	  display_digit(ST_limit/10-(ST_limit/100)*10,0);
          	  break;
      case 5:
          	  clear_display();
          	  display_digit('C',3);
          	  display_digit('R',2);
          	  display_digit(ratio,1);
          	  display_digit(ratio*10-((int)ratio)*10,0);
          	  break;
      case 6:
          	  clear_display();
          	  display_digit('C',3);
          	  display_digit('T',2);
          	  display_digit((threshold)/10000,1);
          	  display_digit((threshold)/1000-((threshold)/10000)*10,0);
          	  break;
      case 7:
          	  clear_display();
          	  display_digit('S',3);
          	  display_digit('P',2);
              display_digit(pilot_att/10,1);
          	  display_digit(pilot_att-(pilot_att/10)*10,0);
          	  break;
     }


   PORTC->ISFR=(1<<3)|(1<<12);
}

void setup_Carriers(){
	SIM->SOPT2|=(1<<24);
    SIM->SCGC6|=(3<<25);
    SIM->SCGC5|=(1<<10);
    //PTB0&PTB2
    //TPM1, TPM2
    //TPM1->pilot tone PTB0
    //TPM2-> 38 khz AM PTB2
    PORTB->PCR[0]|=(3<<8);
    PORTB->PCR[2]|=(3<<8);
    TPM1->MOD=48000/19-1;//19 khz pilot tone
    TPM1->CONTROLS[0].CnSC=(10<<2);
    TPM1->CONTROLS[0].CnV=(48000/19)/2;//50% duty by default
    TPM2->MOD=48000/38-1;//38 khz dsb signal
    TPM2->CONTROLS[0].CnSC=(10<<2);
    TPM2->CONTROLS[0].CnV=0;//AM modulate
    TPM1->SC|=(1<<3);
    TPM2->SC|=(1<<3);

}
int calibrate_ADC(){
short holder=0;
ADC0->SC3=(1<<2)|(1<<7);
while((ADC0->SC3&(1<<7))!=0){}//wait for procedure to exit
if((ADC0->SC3&(1<<7))!=0){//on calibration fail
	return -1;
}
//calibration procedure as defined in the KL46z reference manual, high and low ends calibrated
holder=ADC0->CLPS+ADC0->CLP0+ADC0->CLP1+ADC0->CLP2+ADC0->CLP3+ADC0->CLP4;
holder=(holder/2)|(1<<15);
ADC0->PG=holder;
holder=ADC0->CLMS+ADC0->CLM0+ADC0->CLM1+ADC0->CLM2+ADC0->CLM3+ADC0->CLM4;
holder=(holder/2)|(1<<15);
ADC0->MG=holder;
ADC0->SC3&=~(1<<2);
return 1;
}

void write_to_DAC(short value){
  DAC0->DAT[0].DATL=(char)value;//dac low value
  DAC0->DAT[0].DATH=(value>>8);//dac high value

}
void set_ADC_channel(short in){
	ADC0->SC1[0]=in|(1<<7);//set the ADC mux to the desired channel
}
int limit(int in,int lim,int max){
	if(in>lim){return lim;}//limiter scope high
	if(in<(max-lim)){return max-lim;}//limiter scope low
	return in;//in limits
}
int noise_gate(int in){
	if(in<ST_gate){return 0;}//if input is less than the stereo gate value, no modulation
	return in;
}
void setup_ADC(){
   SIM->SCGC6|=(1<<27);
   SIM->SCGC5|=(1<<13);
   set_ADC_channel(3);//calibrate on a non-used channel
   calibrate_ADC();//calibration procedure to achieve the best audio
   ADC0->CFG1=(3<<2);
   ADC0->CFG2=7;
   //we will be using PTE16 and PTE18
   //they are ADC by default
   //PTE16 will be left ADC0_DP1
   //PTE18 will be right ADC0_DP2
}
int compress(int input){
	if(input<gate){return input;}
	if(input>threshold){
		return input/ratio;
	}
	return input*ratio;

}
void setup_DAC(){
 SIM->SCGC6|=(1<<31);
 //PTE30, mono audio output, default pcr is DAC
 SIM->SCGC5|=(1<<13);
 DAC0->C0=(1<<7)|(1<<6);//dac settings
}
float no_neg(float in){
	if(in<0){
		return -in;
	}
	return in;
}
void setup_button_interrupts(){
 //PTC3- sw1
 //PTC12 -sw2
	SIM->SCGC5|=(1<<11);//user interface to control the limiters and stereo amplifiers
	PORTC->PCR[3]|=(10<<16)|3;
	PORTC->PCR[12]|=(10<<16)|3;
	NVIC_EnableIRQ(31);//button interrupt
}
int RIGHT=0;
int LEFT=0;
char channel=1;
int main(void) {

    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif
    setup_display();
    display_text("on");
    setup_Carriers();
    setup_ADC();
    setup_DAC();
    setup_button_interrupts();
    set_ADC_channel(1);
    set_pilot_att();
    /* Force the counter to be placed into memory. */

    /* Enter an infinite loop, just incrementing a counter. */
    while(1) {
      write_to_DAC(limit((((RIGHT+LEFT)*DAC_vol)/2)/16,DAC_limit,4095));
      TPM2->CONTROLS[0].CnV=limit(((noise_gate(no_neg(RIGHT-LEFT))*((float)ST_diff/10))/103),ST_limit,630);
      if((ADC0->SC1[0]&(1<<7))!=0){
    	  if(channel==1){LEFT=compress(ADC0->R[0]);channel=2;}else{RIGHT=compress(ADC0->R[0]);channel=1;}
    	  set_ADC_channel(channel);
      }
    }
    return 0 ;
}
