//author: Evan Nikitin



#include "MKL46Z4.h"
#include "pin_mux.h"
#include "board.h"

#include "ikran.h"
//display functions


//front is the column //back is the row
short Get_Pin(char number){
	switch(number){
	case 0: return 37;
	case 1: return 17;
	case 2: return 7;
	case 3: return 8;
	case 4: return 53;
	case 5: return 38;
	case 6: return 10;
	case 7: return 11;


	}
    return 37;
}
void turn_on_rows(){
	LCD->WF8B[40]=0x11;
	LCD->WF8B[52]=0x22;
	LCD->WF8B[19]=0x44;
	LCD->WF8B[18]=0x88;
}
void trigger_trace(short segmentfront,short segmentback,short position,char clear){

    if(clear==CLEAR_T){
    	LCD->WF8B[Get_Pin(position*2)]&=~segmentfront; LCD->WF8B[Get_Pin(position*2+1)]&=~segmentback;
    }
    if(clear==SET_T){
    	 LCD->WF8B[Get_Pin(position*2)]|=segmentfront; LCD->WF8B[Get_Pin(position*2+1)]|=segmentback;
    }
}

void clear_display(){
	int i;
	        for(i=0;i<64;i++){

	        	LCD->WF8B[i]=0;
	        }
   turn_on_rows();
}

void setup_display(){
	  SIM->SCGC5|=(15<<10)|(1<<19);//enable all ports after B and the lcd driver
	        //PTD0, common for the first digit
	        //lcd, optimal settings
	          PORTB->PCR[7]=0;     //Set to LCD
	          PORTB->PCR[8]=0;
	          PORTD->PCR[0]=0;
		      PORTE->PCR[4]=0;
		      PORTE->PCR[5]=0;
	          PORTB->PCR[10]=0;
	          PORTB->PCR[11]=0;
	          PORTB->PCR[21]=0;
	          PORTB->PCR[22]=0;
	          PORTB->PCR[23]=0;
	          PORTC->PCR[17]=0;
	          PORTC->PCR[18]=0;
          //enable sw1 and sw2
	          PORTC->PCR[3]=(1<<8)|3;
	          PORTC->PCR[12]=(1<<8)|3;

	        GPIOC->PDDR&=~(1<<3);
	        GPIOC->PDDR&=~(1<<12);

	        LCD->PEN[0]|=(1<<19)|(1<<18);//enabled pins
	        LCD->PEN[1]|=(1<<20)|(1<<8);
	        LCD->BPEN[0]|=(1<<19)|(1<<18);//back planes
	        LCD->BPEN[1]|=(1<<20)|(1<<8);
	        LCD->PEN[0]|=(1<<17)|(1<<7)|(1<<8)|(1<<10)|(1<<11);//digits
	        LCD->PEN[1]|=(1<<5)|(1<<6)|(1<<21);//
	        LCD->GCR|=(2<<3)|(1<<23)|(1<<6)|(1<<7);

	        int s;
	        for(s=0;s<16;s++){
	        	LCD->WF[s]=0;//clear all wvae form registers

	        }
	        LCD->WF[4]=(0x88<<16)|(0x44<<24);//set the waveforms on interfere
	        LCD->WF[10]=0x11;
	        LCD->WF[13]=0x22;
	        //when two pwm signals match, the segment turns dark
	        clear_display();


}
void display_digit(char in,char row){
    //row can be one through 4
   switch(in){
    case '0':
    case 0:
    	trigger_trace(SEGA|SEGC|SEGD,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case '1':
    case 1:
    	trigger_trace(SEGA|SEGC,0,row,SET_T);
    	break;
    case '2':
    case 2:
    	trigger_trace(SEGB|SEGC|SEGD,SEGB|SEGA,row,SET_T);
    	break;
    case '3':
    case 3:
    	trigger_trace(SEGA|SEGB|SEGC|SEGD,SEGA,row,SET_T);
    	break;
    case '4':
    case 4:
    	trigger_trace(SEGA|SEGB|SEGC,SEGC,row,SET_T);
    	break;
    case '5':
    case 5:
    	trigger_trace(SEGA|SEGB|SEGD,SEGA|SEGC,row,SET_T);
    	break;
    case '6':
    case 6:
    	trigger_trace(SEGA|SEGB|SEGD,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case '7':
    case 7:
    	trigger_trace(SEGA|SEGC|SEGD,0,row,SET_T);
    	break;
    case '8':
    case 8:
    	trigger_trace(SEGA|SEGB|SEGC|SEGD,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case '9':
    case 9:
    	trigger_trace(SEGA|SEGB|SEGC|SEGD,SEGA|SEGC,row,SET_T);
    	break;
    case 'a':
    case 'A':
    	trigger_trace(SEGA|SEGC|SEGD|SEGB,SEGC|SEGB,row,SET_T);
        break;
    case 'b':
    case 'B':
    	trigger_trace(SEGA|SEGB,SEGB|SEGC|SEGA,row,SET_T);
    	break;
    case 'c':
    case 'C':
    	trigger_trace(SEGD,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'd':
    case 'D':
    	trigger_trace(SEGA|SEGB|SEGC,SEGA|SEGB,row,SET_T);
    	break;
    case 'e':
    case 'E':
    	trigger_trace(SEGB|SEGD,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'f':
    case 'F':
    	trigger_trace(SEGB|SEGD,SEGB|SEGC,row,SET_T);
    	break;
    case 'g':
    case 'G':
    	trigger_trace(SEGA|SEGD,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'H':
    case 'h':
    	trigger_trace(SEGA|SEGB|SEGC,SEGB|SEGC,row,SET_T);
    	break;
    case 'i':
    case 'I':
    	trigger_trace(SEGD,SEGB,row,SET_T);
    	break;
    case 'j':
    case 'J':
    	trigger_trace(SEGA|SEGC,SEGA,row,SET_T);
    	break;
    case 'k':
    case 'K':
    	trigger_trace(SEGB,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'l':
    case 'L':
    	trigger_trace(0,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'm':
    case 'M':
    	trigger_trace(SEGA|SEGC,SEGB|SEGC,row,SET_T);
    	break;
    case 'N':
    case 'n':
    	trigger_trace(SEGA|SEGB,SEGB,row,SET_T);
    	break;
    case 'o':
    case 'O':
    	trigger_trace(SEGA|SEGB,SEGB|SEGA,row,SET_T);
    	break;
    case 'p':
    case 'P':
    	trigger_trace(SEGC|SEGB|SEGD,SEGB|SEGC,row,SET_T);
    	break;
    case 'q':
    case 'Q':
    	trigger_trace(SEGA|SEGB|SEGC|SEGD,SEGC,row,SET_T);
    	break;
    case 'r':
    case 'R':
    	trigger_trace(SEGB,SEGB,row,SET_T);
    	break;
    case 's':
    case 'S':
    	trigger_trace(SEGB|SEGA,SEGC|SEGA,row,SET_T);
    	break;
    case 't':
    case 'T':
    	trigger_trace(SEGB,SEGB|SEGC,row,SET_T);
    	break;
    case 'u':
    case 'U':
    	trigger_trace(SEGA,SEGB|SEGA,row,SET_T);
    	break;
    case 'v':
    case 'V':
    	trigger_trace(SEGA|SEGC,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'w':
    case 'W':
    	trigger_trace(SEGA|SEGB|SEGC,SEGA|SEGB|SEGC,row,SET_T);
    	break;
    case 'x':
    case 'X':
    	trigger_trace(SEGA|SEGB|SEGC,SEGB|SEGC,row,SET_T);
    	break;
    case 'y':
    case 'Y':
    	trigger_trace(SEGA|SEGB|SEGC,SEGA|SEGC,row,SET_T);
    	break;
    case 'z':
    case 'Z':
    	trigger_trace(SEGC|SEGB,SEGB,row,SET_T);
    	break;
    case ' ':
    	trigger_trace(0,0,row,SET_T);
    	break;
    case ':':
	    trigger_trace(0,SEGD,3,SET_T);
	    break;
    case '-':
    	trigger_trace(SEGB,0,row,SET_T);
        break;
    case '_':
    	trigger_trace(0,SEGA,row,SET_T);
    	 break;
   }

}
void display_text(char *in){
	short i;
	for(i=0;i<4;i++){
		if(in[i]=='\0'){break;}
		display_digit(in[i],3-i);
	}

}
void display_number(short num){
  if(num>9999){

	  return;
  }
  char seg1=num/1000;
  char seg2=(num-seg1*1000)/100;
  char seg3=(num-seg1*1000-seg2*100)/10;
  char seg4=(num-seg1*1000-seg2*100-seg3*10);
  display_digit(seg4,0);
  display_digit(seg3,1);
  display_digit(seg2,2);
  display_digit(seg1,3);
}
void scrolling_text_dialogue(char* input){
 display_text(input);
 short pos=0;
 short size=0;
 short i;
 for(i=0;input[i]!='\0';i++){
	 size++;
 }
 char toggle1=0;
 char toggle2=0;
 while((GPIOC->PDIR&(1<<3))==0||(GPIOC->PDIR&(1<<12))==0){}
 while(toggle1==0){
	 if((GPIOC->PDIR&(1<<3))==0){
		 toggle1=1;
	 }else{toggle1=0;}
	 if((GPIOC->PDIR&(1<<12))==0){
		 if(toggle2==0){
			 clear_display();
			 pos++;
			 if(pos>size-3){
				 pos=0;
			 }
			 display_text(input+pos);
		 }
	 		 toggle2=1;
	 }else{toggle2=0;}


 }
 while((GPIOC->PDIR&(1<<3))==0||(GPIOC->PDIR&(1<<12))==0){}
 clear_display();
}
char number_select(char *show,short bounds){
   char c=0;
   char toggle1=0;
   char toggle2=0;
   display_digit(show[0],3);
   display_digit(show[1],2);
   display_digit(':',0);
   display_digit(c,0);
   while((GPIOC->PDIR&(1<<3))==0||(GPIOC->PDIR&(1<<12))==0){}
   while(toggle1==0){
  	 if((GPIOC->PDIR&(1<<3))==0){
  		 toggle1=1;
  	 }else{toggle1=0;}
  	 if((GPIOC->PDIR&(1<<12))==0){
  		 if(toggle2==0){
  			 clear_display();
  			 c++;
  			 if(c>9||c>bounds){
  				 c=0;
  			 }
  			 display_digit(show[0],3);
  			 display_digit(show[1],2);
  			 display_digit(':',0);
  			 display_digit(c,0);
  		 }
  	 		 toggle2=1;
  	 }else{toggle2=0;}


   }
   while((GPIOC->PDIR&(1<<3))==0||(GPIOC->PDIR&(1<<12))==0){}
   clear_display();
   return c;

}
char getkey(){
	if((GPIOC->PDIR&(1<<3))==0||(GPIOC->PDIR&(1<<12))==0){
		char rval=2;
		if((GPIOC->PDIR&(1<<3))==0){rval=1;}
		while((GPIOC->PDIR&(1<<3))==0||(GPIOC->PDIR&(1<<12))==0){}
		return rval;
	}
	return 0;
}
